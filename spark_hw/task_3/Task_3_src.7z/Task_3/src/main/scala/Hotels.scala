import org.apache.spark.sql.SparkSession
import java.nio.file.Paths
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, desc}


object MainApp {

  def GetNotBookedHotels(df: DataFrame): DataFrame ={
    val df2 = df.filter(
      col("is_booking") === 0 &&
        col("srch_children_cnt") > 0
    )

    df2.groupBy(
      "hotel_continent",
      "hotel_country",
      "hotel_market"
    ).count().sort(desc("count")).limit(3)
  }


  def main(args: Array[String]) {
    val file_in_path = Paths.get("train.csv.gz").toAbsolutePath.toString
    val spark = SparkSession.builder.master("local[*]").appName("popular_countries").getOrCreate()

    val df = spark.read.format(
      "csv"
    ).option(
      "header", "true"
    ).load(file_in_path)

    val df2 = GetNotBookedHotels(df)

    df2.show()
  }

}

