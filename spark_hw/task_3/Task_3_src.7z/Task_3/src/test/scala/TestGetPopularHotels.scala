import org.scalatest.FunSuite
import MainApp.GetNotBookedHotels
import org.apache.spark.sql.SparkSession
import TestDataGenerator.{getDFSample, getExpectedResult}

class TestGetPopularHotels extends FunSuite{

  test("Test GetNotBookedHotels") {
    val spark = SparkSession.builder.master("local[*]").appName("popular_countries").getOrCreate()

    val sampleDF = getDFSample(spark)
    val expectedResult = getExpectedResult(spark)
    val result = GetNotBookedHotels(sampleDF)
    assert(expectedResult.collectAsList() == result.collectAsList())
  }

}

